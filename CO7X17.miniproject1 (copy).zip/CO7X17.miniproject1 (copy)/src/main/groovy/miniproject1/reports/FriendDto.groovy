package miniproject1.reports

class FriendDto {
	String name
	String description
	int noTweets
	int noMaxRetweets
	List<String> popularTweets = new ArrayList<>()
}
